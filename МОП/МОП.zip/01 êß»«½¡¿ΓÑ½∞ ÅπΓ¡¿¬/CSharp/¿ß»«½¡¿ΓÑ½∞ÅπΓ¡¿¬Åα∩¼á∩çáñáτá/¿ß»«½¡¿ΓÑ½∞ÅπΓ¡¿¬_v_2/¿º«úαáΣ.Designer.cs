﻿namespace исполнительПутник_v_2
{
    partial class изограф
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(изограф));
            this.панельМеню = new System.Windows.Forms.Panel();
            this.bПроверкаРешения = new System.Windows.Forms.Button();
            this.bРешение = new System.Windows.Forms.Button();
            this.bСреда = new System.Windows.Forms.Button();
            this.mSНазначение = new System.Windows.Forms.MenuStrip();
            this.tSMenuПапаметровЗадачи = new System.Windows.Forms.ToolStripMenuItem();
            this.tSMenuIТема = new System.Windows.Forms.ToolStripMenuItem();
            this.tSMОператорWhile = new System.Windows.Forms.ToolStripMenuItem();
            this.операторыWhileИIf = new System.Windows.Forms.ToolStripMenuItem();
            this.любыеОператоры = new System.Windows.Forms.ToolStripMenuItem();
            this.номерЗадачиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tSTBНомерЗадачи = new System.Windows.Forms.ToolStripTextBox();
            this.tSMГотово = new System.Windows.Forms.ToolStripMenuItem();
            this.pBФиолетовый = new System.Windows.Forms.PictureBox();
            this.pBСиний = new System.Windows.Forms.PictureBox();
            this.pBГолубой = new System.Windows.Forms.PictureBox();
            this.pBЗеленый = new System.Windows.Forms.PictureBox();
            this.pBЖелтый = new System.Windows.Forms.PictureBox();
            this.pBОранжевый = new System.Windows.Forms.PictureBox();
            this.pBКрасный = new System.Windows.Forms.PictureBox();
            this.pBБелый = new System.Windows.Forms.PictureBox();
            this.pBПрепятствиеС = new System.Windows.Forms.PictureBox();
            this.pBПрепятствиеК = new System.Windows.Forms.PictureBox();
            this.pBПутникЗ = new System.Windows.Forms.PictureBox();
            this.pBПутникЮ = new System.Windows.Forms.PictureBox();
            this.pBПутникВ = new System.Windows.Forms.PictureBox();
            this.pBПутникС = new System.Windows.Forms.PictureBox();
            this.полеПутника = new System.Windows.Forms.PictureBox();
            this.панельМеню.SuspendLayout();
            this.mSНазначение.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBФиолетовый)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBСиний)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBГолубой)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBЗеленый)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBЖелтый)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBОранжевый)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBКрасный)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBБелый)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBПрепятствиеС)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBПрепятствиеК)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBПутникЗ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBПутникЮ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBПутникВ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBПутникС)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.полеПутника)).BeginInit();
            this.SuspendLayout();
            // 
            // панельМеню
            // 
            this.панельМеню.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar;
            this.панельМеню.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.панельМеню.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.панельМеню.Controls.Add(this.bПроверкаРешения);
            this.панельМеню.Controls.Add(this.bРешение);
            this.панельМеню.Controls.Add(this.bСреда);
            this.панельМеню.Controls.Add(this.mSНазначение);
            this.панельМеню.Location = new System.Drawing.Point(1, 1);
            this.панельМеню.Margin = new System.Windows.Forms.Padding(4);
            this.панельМеню.Name = "панельМеню";
            this.панельМеню.Size = new System.Drawing.Size(1298, 53);
            this.панельМеню.TabIndex = 2;
            // 
            // bПроверкаРешения
            // 
            this.bПроверкаРешения.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bПроверкаРешения.Location = new System.Drawing.Point(388, 4);
            this.bПроверкаРешения.Margin = new System.Windows.Forms.Padding(4);
            this.bПроверкаРешения.Name = "bПроверкаРешения";
            this.bПроверкаРешения.Size = new System.Drawing.Size(206, 44);
            this.bПроверкаРешения.TabIndex = 3;
            this.bПроверкаРешения.Text = "Отладка решения";
            this.bПроверкаРешения.UseVisualStyleBackColor = true;
            this.bПроверкаРешения.Click += new System.EventHandler(this.bПроверкаРешения_Click);
            // 
            // bРешение
            // 
            this.bРешение.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bРешение.Location = new System.Drawing.Point(607, 4);
            this.bРешение.Margin = new System.Windows.Forms.Padding(4);
            this.bРешение.Name = "bРешение";
            this.bРешение.Size = new System.Drawing.Size(206, 44);
            this.bРешение.TabIndex = 2;
            this.bРешение.Text = "Тестирование решения";
            this.bРешение.UseVisualStyleBackColor = true;
            this.bРешение.Click += new System.EventHandler(this.bРешение_Click);
            // 
            // bСреда
            // 
            this.bСреда.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bСреда.Location = new System.Drawing.Point(169, 4);
            this.bСреда.Margin = new System.Windows.Forms.Padding(4);
            this.bСреда.Name = "bСреда";
            this.bСреда.Size = new System.Drawing.Size(206, 44);
            this.bСреда.TabIndex = 1;
            this.bСреда.Text = "Построение среды";
            this.bСреда.UseVisualStyleBackColor = true;
            this.bСреда.Click += new System.EventHandler(this.bСреда_Click);
            // 
            // mSНазначение
            // 
            this.mSНазначение.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.mSНазначение.Dock = System.Windows.Forms.DockStyle.None;
            this.mSНазначение.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.mSНазначение.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tSMenuПапаметровЗадачи});
            this.mSНазначение.Location = new System.Drawing.Point(4, 12);
            this.mSНазначение.Name = "mSНазначение";
            this.mSНазначение.Size = new System.Drawing.Size(136, 25);
            this.mSНазначение.TabIndex = 4;
            this.mSНазначение.Text = "menuПараметрыЗадачи";
            // 
            // tSMenuПапаметровЗадачи
            // 
            this.tSMenuПапаметровЗадачи.BackColor = System.Drawing.SystemColors.Menu;
            this.tSMenuПапаметровЗадачи.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tSMenuIТема,
            this.номерЗадачиToolStripMenuItem});
            this.tSMenuПапаметровЗадачи.Name = "tSMenuПапаметровЗадачи";
            this.tSMenuПапаметровЗадачи.Size = new System.Drawing.Size(155, 21);
            this.tSMenuПапаметровЗадачи.Text = "ПарамерыЗадачи";
            // 
            // tSMenuIТема
            // 
            this.tSMenuIТема.BackColor = System.Drawing.SystemColors.Menu;
            this.tSMenuIТема.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tSMОператорWhile,
            this.операторыWhileИIf,
            this.любыеОператоры});
            this.tSMenuIТема.Name = "tSMenuIТема";
            this.tSMenuIТема.ShowShortcutKeys = false;
            this.tSMenuIТема.Size = new System.Drawing.Size(181, 24);
            this.tSMenuIТема.Text = "Тема";
            // 
            // tSMОператорWhile
            // 
            this.tSMОператорWhile.BackColor = System.Drawing.SystemColors.Menu;
            this.tSMОператорWhile.Enabled = false;
            this.tSMОператорWhile.Name = "tSMОператорWhile";
            this.tSMОператорWhile.Size = new System.Drawing.Size(242, 24);
            this.tSMОператорWhile.Text = "Оператор While";
            this.tSMОператорWhile.Click += new System.EventHandler(this.tSMОператорWhile_Click);
            // 
            // операторыWhileИIf
            // 
            this.операторыWhileИIf.BackColor = System.Drawing.SystemColors.Menu;
            this.операторыWhileИIf.Enabled = false;
            this.операторыWhileИIf.Name = "операторыWhileИIf";
            this.операторыWhileИIf.Size = new System.Drawing.Size(242, 24);
            this.операторыWhileИIf.Text = "Операторы While и If";
            this.операторыWhileИIf.Click += new System.EventHandler(this.операторыWhileИIf_Click);
            // 
            // любыеОператоры
            // 
            this.любыеОператоры.BackColor = System.Drawing.SystemColors.Menu;
            this.любыеОператоры.Enabled = false;
            this.любыеОператоры.Name = "любыеОператоры";
            this.любыеОператоры.Size = new System.Drawing.Size(242, 24);
            this.любыеОператоры.Text = "Любые операторы";
            this.любыеОператоры.Click += new System.EventHandler(this.любыеОператоры_Click);
            // 
            // номерЗадачиToolStripMenuItem
            // 
            this.номерЗадачиToolStripMenuItem.BackColor = System.Drawing.SystemColors.Menu;
            this.номерЗадачиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tSTBНомерЗадачи,
            this.tSMГотово});
            this.номерЗадачиToolStripMenuItem.Name = "номерЗадачиToolStripMenuItem";
            this.номерЗадачиToolStripMenuItem.Size = new System.Drawing.Size(181, 24);
            this.номерЗадачиToolStripMenuItem.Text = "Номер задачи";
            // 
            // tSTBНомерЗадачи
            // 
            this.tSTBНомерЗадачи.BackColor = System.Drawing.SystemColors.Menu;
            this.tSTBНомерЗадачи.Name = "tSTBНомерЗадачи";
            this.tSTBНомерЗадачи.Size = new System.Drawing.Size(185, 27);
            // 
            // tSMГотово
            // 
            this.tSMГотово.BackColor = System.Drawing.SystemColors.Menu;
            this.tSMГотово.Name = "tSMГотово";
            this.tSMГотово.Size = new System.Drawing.Size(245, 24);
            this.tSMГотово.Text = "Готово";
            this.tSMГотово.Click += new System.EventHandler(this.tSMГотово_Click);
            // 
            // pBФиолетовый
            // 
            this.pBФиолетовый.BackColor = System.Drawing.Color.Transparent;
            this.pBФиолетовый.Image = ((System.Drawing.Image)(resources.GetObject("pBФиолетовый.Image")));
            this.pBФиолетовый.Location = new System.Drawing.Point(720, 630);
            this.pBФиолетовый.Name = "pBФиолетовый";
            this.pBФиолетовый.Size = new System.Drawing.Size(42, 42);
            this.pBФиолетовый.TabIndex = 23;
            this.pBФиолетовый.TabStop = false;
            this.pBФиолетовый.Visible = false;
            // 
            // pBСиний
            // 
            this.pBСиний.BackColor = System.Drawing.Color.Transparent;
            this.pBСиний.Image = ((System.Drawing.Image)(resources.GetObject("pBСиний.Image")));
            this.pBСиний.Location = new System.Drawing.Point(665, 630);
            this.pBСиний.Name = "pBСиний";
            this.pBСиний.Size = new System.Drawing.Size(42, 42);
            this.pBСиний.TabIndex = 22;
            this.pBСиний.TabStop = false;
            this.pBСиний.Visible = false;
            // 
            // pBГолубой
            // 
            this.pBГолубой.BackColor = System.Drawing.Color.Transparent;
            this.pBГолубой.Image = ((System.Drawing.Image)(resources.GetObject("pBГолубой.Image")));
            this.pBГолубой.Location = new System.Drawing.Point(610, 630);
            this.pBГолубой.Name = "pBГолубой";
            this.pBГолубой.Size = new System.Drawing.Size(42, 42);
            this.pBГолубой.TabIndex = 21;
            this.pBГолубой.TabStop = false;
            this.pBГолубой.Visible = false;
            // 
            // pBЗеленый
            // 
            this.pBЗеленый.BackColor = System.Drawing.Color.Transparent;
            this.pBЗеленый.Image = ((System.Drawing.Image)(resources.GetObject("pBЗеленый.Image")));
            this.pBЗеленый.Location = new System.Drawing.Point(555, 630);
            this.pBЗеленый.Name = "pBЗеленый";
            this.pBЗеленый.Size = new System.Drawing.Size(42, 42);
            this.pBЗеленый.TabIndex = 20;
            this.pBЗеленый.TabStop = false;
            this.pBЗеленый.Visible = false;
            // 
            // pBЖелтый
            // 
            this.pBЖелтый.BackColor = System.Drawing.Color.Transparent;
            this.pBЖелтый.Image = ((System.Drawing.Image)(resources.GetObject("pBЖелтый.Image")));
            this.pBЖелтый.Location = new System.Drawing.Point(500, 630);
            this.pBЖелтый.Name = "pBЖелтый";
            this.pBЖелтый.Size = new System.Drawing.Size(42, 42);
            this.pBЖелтый.TabIndex = 19;
            this.pBЖелтый.TabStop = false;
            this.pBЖелтый.Visible = false;
            // 
            // pBОранжевый
            // 
            this.pBОранжевый.BackColor = System.Drawing.Color.Transparent;
            this.pBОранжевый.Image = ((System.Drawing.Image)(resources.GetObject("pBОранжевый.Image")));
            this.pBОранжевый.Location = new System.Drawing.Point(445, 630);
            this.pBОранжевый.Name = "pBОранжевый";
            this.pBОранжевый.Size = new System.Drawing.Size(42, 42);
            this.pBОранжевый.TabIndex = 18;
            this.pBОранжевый.TabStop = false;
            this.pBОранжевый.Visible = false;
            // 
            // pBКрасный
            // 
            this.pBКрасный.BackColor = System.Drawing.Color.Transparent;
            this.pBКрасный.Image = ((System.Drawing.Image)(resources.GetObject("pBКрасный.Image")));
            this.pBКрасный.Location = new System.Drawing.Point(390, 630);
            this.pBКрасный.Name = "pBКрасный";
            this.pBКрасный.Size = new System.Drawing.Size(42, 42);
            this.pBКрасный.TabIndex = 17;
            this.pBКрасный.TabStop = false;
            this.pBКрасный.Visible = false;
            // 
            // pBБелый
            // 
            this.pBБелый.BackColor = System.Drawing.Color.Transparent;
            this.pBБелый.Image = ((System.Drawing.Image)(resources.GetObject("pBБелый.Image")));
            this.pBБелый.Location = new System.Drawing.Point(335, 630);
            this.pBБелый.Name = "pBБелый";
            this.pBБелый.Size = new System.Drawing.Size(42, 42);
            this.pBБелый.TabIndex = 16;
            this.pBБелый.TabStop = false;
            this.pBБелый.Visible = false;
            // 
            // pBПрепятствиеС
            // 
            this.pBПрепятствиеС.BackColor = System.Drawing.Color.Transparent;
            this.pBПрепятствиеС.Image = ((System.Drawing.Image)(resources.GetObject("pBПрепятствиеС.Image")));
            this.pBПрепятствиеС.Location = new System.Drawing.Point(280, 630);
            this.pBПрепятствиеС.Name = "pBПрепятствиеС";
            this.pBПрепятствиеС.Size = new System.Drawing.Size(42, 42);
            this.pBПрепятствиеС.TabIndex = 15;
            this.pBПрепятствиеС.TabStop = false;
            this.pBПрепятствиеС.Visible = false;
            // 
            // pBПрепятствиеК
            // 
            this.pBПрепятствиеК.BackColor = System.Drawing.Color.Transparent;
            this.pBПрепятствиеК.Image = ((System.Drawing.Image)(resources.GetObject("pBПрепятствиеК.Image")));
            this.pBПрепятствиеК.Location = new System.Drawing.Point(225, 630);
            this.pBПрепятствиеК.Name = "pBПрепятствиеК";
            this.pBПрепятствиеК.Size = new System.Drawing.Size(42, 42);
            this.pBПрепятствиеК.TabIndex = 14;
            this.pBПрепятствиеК.TabStop = false;
            this.pBПрепятствиеК.Visible = false;
            // 
            // pBПутникЗ
            // 
            this.pBПутникЗ.BackColor = System.Drawing.Color.Transparent;
            this.pBПутникЗ.Image = ((System.Drawing.Image)(resources.GetObject("pBПутникЗ.Image")));
            this.pBПутникЗ.Location = new System.Drawing.Point(170, 630);
            this.pBПутникЗ.Name = "pBПутникЗ";
            this.pBПутникЗ.Size = new System.Drawing.Size(42, 42);
            this.pBПутникЗ.TabIndex = 13;
            this.pBПутникЗ.TabStop = false;
            this.pBПутникЗ.Visible = false;
            // 
            // pBПутникЮ
            // 
            this.pBПутникЮ.BackColor = System.Drawing.Color.Transparent;
            this.pBПутникЮ.Image = ((System.Drawing.Image)(resources.GetObject("pBПутникЮ.Image")));
            this.pBПутникЮ.Location = new System.Drawing.Point(115, 630);
            this.pBПутникЮ.Name = "pBПутникЮ";
            this.pBПутникЮ.Size = new System.Drawing.Size(42, 42);
            this.pBПутникЮ.TabIndex = 12;
            this.pBПутникЮ.TabStop = false;
            this.pBПутникЮ.Visible = false;
            // 
            // pBПутникВ
            // 
            this.pBПутникВ.BackColor = System.Drawing.Color.Transparent;
            this.pBПутникВ.Image = ((System.Drawing.Image)(resources.GetObject("pBПутникВ.Image")));
            this.pBПутникВ.Location = new System.Drawing.Point(60, 630);
            this.pBПутникВ.Name = "pBПутникВ";
            this.pBПутникВ.Size = new System.Drawing.Size(42, 42);
            this.pBПутникВ.TabIndex = 11;
            this.pBПутникВ.TabStop = false;
            this.pBПутникВ.Visible = false;
            // 
            // pBПутникС
            // 
            this.pBПутникС.BackColor = System.Drawing.Color.Transparent;
            this.pBПутникС.Image = ((System.Drawing.Image)(resources.GetObject("pBПутникС.Image")));
            this.pBПутникС.Location = new System.Drawing.Point(5, 630);
            this.pBПутникС.Name = "pBПутникС";
            this.pBПутникС.Size = new System.Drawing.Size(42, 42);
            this.pBПутникС.TabIndex = 10;
            this.pBПутникС.TabStop = false;
            this.pBПутникС.Visible = false;
            // 
            // полеПутника
            // 
            this.полеПутника.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.полеПутника.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.полеПутника.Location = new System.Drawing.Point(1, 62);
            this.полеПутника.Name = "полеПутника";
            this.полеПутника.Size = new System.Drawing.Size(1300, 615);
            this.полеПутника.TabIndex = 9;
            this.полеПутника.TabStop = false;
            this.полеПутника.Click += new System.EventHandler(this.полеПутника_Click);
            // 
            // изограф
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1311, 679);
            this.Controls.Add(this.pBФиолетовый);
            this.Controls.Add(this.pBСиний);
            this.Controls.Add(this.pBГолубой);
            this.Controls.Add(this.pBЗеленый);
            this.Controls.Add(this.pBЖелтый);
            this.Controls.Add(this.pBОранжевый);
            this.Controls.Add(this.pBКрасный);
            this.Controls.Add(this.pBБелый);
            this.Controls.Add(this.pBПрепятствиеС);
            this.Controls.Add(this.pBПрепятствиеК);
            this.Controls.Add(this.pBПутникЗ);
            this.Controls.Add(this.pBПутникЮ);
            this.Controls.Add(this.pBПутникВ);
            this.Controls.Add(this.pBПутникС);
            this.Controls.Add(this.полеПутника);
            this.Controls.Add(this.панельМеню);
            this.Font = new System.Drawing.Font("Times New Roman", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainMenuStrip = this.mSНазначение;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "изограф";
            this.Text = "исполнительПутник";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.панельМеню.ResumeLayout(false);
            this.панельМеню.PerformLayout();
            this.mSНазначение.ResumeLayout(false);
            this.mSНазначение.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBФиолетовый)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBСиний)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBГолубой)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBЗеленый)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBЖелтый)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBОранжевый)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBКрасный)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBБелый)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBПрепятствиеС)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBПрепятствиеК)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBПутникЗ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBПутникЮ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBПутникВ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBПутникС)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.полеПутника)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel панельМеню;
        private System.Windows.Forms.Button bСреда;
        private System.Windows.Forms.Button bРешение;
        private System.Windows.Forms.Button bПроверкаРешения;
        private System.Windows.Forms.MenuStrip mSНазначение;
        private System.Windows.Forms.ToolStripMenuItem tSMenuПапаметровЗадачи;
        private System.Windows.Forms.ToolStripMenuItem tSMenuIТема;
        private System.Windows.Forms.ToolStripMenuItem tSMОператорWhile;
        private System.Windows.Forms.ToolStripMenuItem операторыWhileИIf;
        private System.Windows.Forms.ToolStripMenuItem любыеОператоры;
        private System.Windows.Forms.ToolStripMenuItem номерЗадачиToolStripMenuItem;
        private System.Windows.Forms.ToolStripTextBox tSTBНомерЗадачи;
        private System.Windows.Forms.ToolStripMenuItem tSMГотово;
        private System.Windows.Forms.PictureBox полеПутника;
        private System.Windows.Forms.PictureBox pBПутникС;
        private System.Windows.Forms.PictureBox pBПутникВ;
        private System.Windows.Forms.PictureBox pBПутникЮ;
        private System.Windows.Forms.PictureBox pBПутникЗ;
        private System.Windows.Forms.PictureBox pBПрепятствиеК;
        private System.Windows.Forms.PictureBox pBПрепятствиеС;
        private System.Windows.Forms.PictureBox pBБелый;
        private System.Windows.Forms.PictureBox pBКрасный;
        private System.Windows.Forms.PictureBox pBОранжевый;
        private System.Windows.Forms.PictureBox pBЖелтый;
        private System.Windows.Forms.PictureBox pBЗеленый;
        private System.Windows.Forms.PictureBox pBГолубой;
        private System.Windows.Forms.PictureBox pBСиний;
        private System.Windows.Forms.PictureBox pBФиолетовый;
    }
}

